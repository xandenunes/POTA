
#ifndef MINHASFUNCOES_H
#define MINHASFUNCOES_H
int somaCubo(int);
int isIn (int,int*, int);
void ordena(int*,int);
int isInBinario (int,int*, int);
long g(long x);
long h(long x);
long fat(long x); 
long fib(int n); 
long fibrec(long n); 
#endif /* MINHASFUNCOES_H */
