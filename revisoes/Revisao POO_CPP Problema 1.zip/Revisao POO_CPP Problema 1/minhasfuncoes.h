
#ifndef MINHASFUNCOES_H
#define MINHASFUNCOES_H

int min(int,int);

#endif /* MINHASFUNCOES_H */
